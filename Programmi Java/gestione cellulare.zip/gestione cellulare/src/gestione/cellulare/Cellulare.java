/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.cellulare;

/**
 *
 * @author Jhon
 */
public class Cellulare {
    int cod;
    int prz;
    int ore;
    public Cellulare(int num,int num2,int num3){
        cod=num;
        prz=num2;
        ore=num3;
    }
}
